# Docker deployment option

This is an additional deployment path; the existing local `docker-compose.yml` is unchanged.

## Before starting

1. Copy `.env.example` to `.env`.
2. Replace `POSTGRES_PASSWORD`, `JWT_SECRET`, and all Razorpay placeholders. Use Razorpay **test mode** first.
3. Set `FRONTEND_URL` to the exact public origin (scheme + host, no path), e.g. `https://cafe.example.com`.
4. Set `BACKEND_PUBLIC_URL` to the public origin serving this app. In this single-origin setup, it is normally the same origin as the frontend.
5. For production photo uploads, do not use `STORAGE_PROVIDER=local` unless persistent storage is guaranteed. Configure `s3` or `cloudinary` and their credentials instead.
6. Do not use the documented development admin credentials in production. Change the admin password immediately after the first login.

## Start

```bash
docker compose --env-file .env -f docker-compose.deploy.yml config
docker compose --env-file .env -f docker-compose.deploy.yml up -d --build
docker compose --env-file .env -f docker-compose.deploy.yml ps
docker compose --env-file .env -f docker-compose.deploy.yml logs --tail=150 backend
```

The frontend is served on port 80 by default (`HTTP_PORT` changes the host port). The Nginx container proxies `/api`, `/ws`, and `/uploads` to Spring Boot, so frontend API calls use the same origin and `VITE_API_URL` stays empty.

## If you still get 502

```bash
docker compose --env-file .env -f docker-compose.deploy.yml ps
docker compose --env-file .env -f docker-compose.deploy.yml logs --tail=200 backend
docker compose --env-file .env -f docker-compose.deploy.yml logs --tail=100 frontend
```

A 502 from Nginx usually means the backend container is stopped/unhealthy or the proxy cannot reach it. A platform-generated 502 may instead mean the platform's configured port/health check is wrong. Do not share `.env` or secret values when sending logs.

## Verification limitation

The current execution environment could not download npm/Maven dependencies, so a dependency-backed frontend/backend build and real payment tests could not be completed here. Real Razorpay checkout/webhook, push notifications, and production storage must be tested with your own credentials before launch. This is an optional Docker setup; hosts requiring separate service settings must use matching build/start commands and port configuration.
