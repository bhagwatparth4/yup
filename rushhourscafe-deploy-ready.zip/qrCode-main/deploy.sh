#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if [[ ! -f .env ]]; then
  echo "ERROR: .env missing. Copy .env.production.example to .env and fill secrets first."
  exit 1
fi
for key in POSTGRES_DB POSTGRES_USER POSTGRES_PASSWORD JWT_SECRET RAZORPAY_KEY_ID RAZORPAY_KEY_SECRET RAZORPAY_WEBHOOK_SECRET; do
  if ! grep -Eq "^${key}=.+" .env || grep -Eq "^${key}=(REPLACE|changeme|replace-me|rzp_test_REPLACE)" .env; then
    echo "ERROR: $key is missing or still a placeholder in .env"
    exit 1
  fi
done
chmod 600 .env
docker compose --env-file .env -f docker-compose.deploy.yml config --quiet
docker compose --env-file .env -f docker-compose.deploy.yml up -d --build
echo
echo "=== Service status ==="
docker compose --env-file .env -f docker-compose.deploy.yml ps
echo
echo "If frontend is healthy but domain does not load, configure Cloudonfire reverse proxy for app.rushhourscafe.in to this VPS port ${HTTP_PORT:-8088} with HTTPS."
