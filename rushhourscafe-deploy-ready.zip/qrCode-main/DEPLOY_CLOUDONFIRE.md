# Cloudonfire deployment notes

## Important
- This deployment keeps the existing Docker volume `cafe_qr_postgres_data` (external) and does not run `down -v`.
- Do not run `docker compose down -v`.
- Use `.env.production.example` as a template, not as the live secrets file.
- Rotate credentials that were shared in chat before production use.
- This Compose publishes frontend on host port 8088 by default; configure Cloudonfire's domain/reverse proxy for `app.rushhourscafe.in` to port 8088 and enable HTTPS.
- Razorpay test keys only allow test transactions. Production UPI requires Razorpay live account activation and live keys.

## Commands
```bash
cp .env.production.example .env
nano .env
chmod +x deploy.sh
./deploy.sh
docker compose --env-file .env -f docker-compose.deploy.yml logs --tail=150 backend
docker compose --env-file .env -f docker-compose.deploy.yml logs --tail=100 frontend
```

## Database note
If the existing PostgreSQL volume was initialized using a different username/password, changing `POSTGRES_USER` or `POSTGRES_PASSWORD` in `.env` will not modify existing database roles. Keep the existing credentials or change the database role password deliberately after taking a backup.

## Reverse proxy
The frontend Nginx container handles SPA routes and proxies `/api`, `/ws`, and `/uploads` internally to the backend. TLS should terminate at Cloudonfire's reverse proxy. Do not expose PostgreSQL port 5432 or Redis port 6379 publicly.
